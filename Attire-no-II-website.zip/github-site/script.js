const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('#site-nav');

menuButton.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(open));
});

nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuButton.setAttribute('aria-expanded', 'false');
}));

const form = document.querySelector('#newsletter-form');
const message = document.querySelector('.form-message');

form.addEventListener('submit', event => {
  event.preventDefault();
  const email = new FormData(form).get('email');
  message.textContent = `You're on the list — we'll write to ${email}.`;
  form.reset();
});

document.querySelector('.notify-trigger').addEventListener('click', () => {
  document.querySelector('#email').focus();
  document.querySelector('#contact').scrollIntoView({ behavior: 'smooth' });
});

document.querySelector('#year').textContent = new Date().getFullYear();
